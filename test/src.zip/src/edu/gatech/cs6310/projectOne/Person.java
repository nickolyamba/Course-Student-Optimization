package edu.gatech.cs6310.projectOne;

public interface Person {
	
}
