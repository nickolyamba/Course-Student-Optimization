package edu.gatech.cs6310.projectOne;

import java.util.HashSet;
import java.util.Set;

public class Student implements Person {
	private int stud_ID;
	private Set<Demand> courseStudSet;
	private Set<Integer> coursesIDSet;
	
	// constructor
	// @param stud_ID the stud_ID to set
	public Student(int stud_ID) {
		this.stud_ID = stud_ID;
		courseStudSet = new HashSet<Demand>();
		coursesIDSet = new HashSet<Integer>();
	}
	
	public void addCourse(Student student, Course course){
		this.courseStudSet.add(new Demand(student, course));
		this.coursesIDSet.add(course.getCourse_ID());
	}
	
	/**
	 * @return a set of courses contained in coursesSet
	 */
	public Set<Course> getCoursesSet() {
		Set<Course> courses = new HashSet<Course>();
		// add course obj to Set courses to return
		for(Demand dem: courseStudSet)
			courses.add(dem.getCourse());
		
		return courses;
	}

	/**
	 * @return the coursesIDSet
	 */
	public Set<Integer> getCoursesIDSet() {
		return coursesIDSet;
	}

	/**
	 * @param coursesSet the coursesSet to set
	 */
	public void setCoursesSet(Set<Demand> coursesSet) {
		this.courseStudSet = coursesSet;
	}

	/**
	 * @return the stud_ID
	 */
	public int getStud_ID() {
		return stud_ID;
	}

}//Student
