package edu.gatech.cs6310.projectOne;

// Sources used: http://galaxy.lamar.edu/~sandrei/CPSC-4360-01/
public class Demand {
	private Course course;
	private Student student; 
	
	public Demand(Student student, Course course) {
		this.course = course;
		this.student = student;
	}

	/**
	 * @return the student
	 */
	public Student getStudent() {
		return student;
	}

	/**
	 * @param student the student to set
	 */
	public void setStudent(Student student) {
		this.student = student;
	}

	/**
	 * @return the course
	 */
	public Course getCourse() {
		return course;
	}

	/**
	 * @param course the course to set
	 */
	public void setCourse(Course course) {
		this.course = course;
	}

}
