package edu.gatech.cs6310.projectOne;

public class ProjectOne {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		float result = (float) 3.1415;
		System.out.printf("X=%.2f", result);
	}

}
