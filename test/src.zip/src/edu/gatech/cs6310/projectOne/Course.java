package edu.gatech.cs6310.projectOne;

import java.util.HashSet;
import java.util.Set;

public class Course {
	private int course_ID;
	private String course_name = "";
	private String course_num = "";
	
	// sets of CourseSem and semesterIDs
	// associated with the given course
	private Set<CourseSem> semCourseSet;
	private Set<Integer> semesterIDSet;
	
	// set of Demand objects, 
	// associated with the given course
	private Set<Demand> studCourseSet;
	
	// Prerequisite sets of Courses and IDs
	private Set<Course> prereqSet; 
	private Set<Integer> prereqIDSet;

	// constructor 
	// @param course_ID, course_num, 
	// course_name to initialize
	public Course(int course_ID, String course_num, String course_name){
		//TODO
	}
	
	// constructor 
	// @param course_ID  to initialize
	public Course(int course_ID){
		this.course_ID = course_ID;
		semCourseSet = new HashSet<CourseSem>();
		semesterIDSet = new HashSet<Integer>();
		studCourseSet = new HashSet<Demand>();
		prereqSet = new HashSet<Course>();
		prereqIDSet = new HashSet<Integer>();
	}
	
	public void addSemester(Semester semester){
		this.semCourseSet.add(new CourseSem(semester));
		this.semesterIDSet.add(semester.getSemester_ID());
	}
	
	public void addStudent(Student student, Course course){
		this.studCourseSet.add(new Demand(student, course));
	}
	
	public void addPrereq(Course course)
	{
		this.prereqSet.add(course);
		this.prereqIDSet.add(course.getCourse_ID());
	}

	/**
	 * @return the course_num
	 */
	public String getCourse_num() {
		return course_num;
	}

	/**
	 * @param course_num the course_num to set
	 */
	public void setCourse_num(String course_num) {
		this.course_num = course_num;
	}

	/**
	 * @return the course_name
	 */
	public String getCourse_name() {
		return course_name;
	}

	/**
	 * @param course_name the course_name to set
	 */
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	/**
	 * @return the course_ID
	 */
	public int getCourse_ID() {
		return course_ID;
	}
	
	/**
	 * @return the semesterSet
	 */
	public Set<Semester> getSemesterSet() {
		Set<Semester> semesters = new HashSet<>();
		
		//get set of Semester obj from semesterSet
		for(CourseSem sem : semCourseSet)
			semesters.add(sem.getSemester());
		
		return semesters;
	}

	/**
	 * @return the semesterIdSet
	 */
	public Set<Integer> getSemesterIDSet() {
		return semesterIDSet;
	}

	/**
	 * @param semesterSet the semesterSet to set
	 */
	public void setSemesterSet(Set<CourseSem> semesterSet){
		this.semCourseSet = semesterSet;
	}
	
	/**
	 * @return the studentSet
	 */
	public Set<Student> getStudentSet(){
		Set<Student> students = new HashSet<>();
		
		//get set of Semester obj from semesterSet
		for(Demand demand : studCourseSet)
			students.add(demand.getStudent());
		
		return students;
	}

	/**
	 * @param studentSet the studentSet to set
	 */
	public void setStudentSet(Set<Demand> studentSet) {
		this.studCourseSet = studentSet;
	}

	/**
	 * @return the prereqSet
	 */
	public Set<Course> getPrereqSet() {
		return prereqSet;
	}

	/**
	 * @param prereqSet the prereqSet to set
	 */
	public void setPrereqSet(Set<Course> prereqSet) {
		this.prereqSet = prereqSet;
	}

	/**
	 * @return the prereqIDSet
	 */
	public Set<Integer> getPrereqIDSet() {
		return prereqIDSet;
	}

	/**
	 * @param prereqIDSet the prereqIDSet to set
	 */
	public void setPrereqIDSet(Set<Integer> prereqIDSet) {
		this.prereqIDSet = prereqIDSet;
	}


}
