package edu.gatech.cs6310.projectOne;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import gurobi.GRB;
import gurobi.GRBEnv;
import gurobi.GRBException;
import gurobi.GRBLinExpr;
import gurobi.GRBModel;
import gurobi.GRBVar;

public class Project1Scheduler implements Scheduler {
	
	// Class to access number of students, 
	// semesters, and courses
	protected class Limits
	{
		int stud;
		int cour;
		int sem;
		
		Limits(int stud, int cour, int sem)
		{
			this.stud = stud; this.cour = cour; this.sem = sem;
		}
	}

	public void calculateSchedule(String pathToStudDemand){
		// TODO Read the test data from the provided folder

		// The following code is an example of how to use the Gurobi solver.
		// Replace the variables, objective, and constraints with those
		// needed to calculate the schedule for the provided data.
		
		// This example has three students and two classes.  Each class is
		// limited to two students. The objective is to maximize the total 
		// number of student-classes taken. It do not deal with semesters
		
		System.out.println(pathToStudDemand);
		//pathToStudDemand = "I:\\Dropbox\\CS 6310 - Software Architecture and Design\\Project 1\\project1-datasets\\large7000.csv";
		
			   /* demand1 - __X = 4__
				* demand2 - __X = 5__
				* demand3 - __X = 9__
				* demand4 - __X = 13__
				* demand5 - __X = 17__
				* demand6 - __X = 4__
				* demand7 - __X = 5__
				* demand8 - __X = 9__
				* demand9 - __X = 13__
				* demand10 - __X = 17__
				* demand11 - __X = 1__
				* demand12 - __X = 3__*/
		
		final int NUM_COURSES = 18; final int NUM_SEM = 12; 
			
		// Declare ArrayLists of Course, Semester and Student objects
		ArrayList<Course> courses = new ArrayList<Course>();
		ArrayList<Semester> semesters = new ArrayList<Semester>();
		ArrayList<Student> students = new ArrayList<Student>();
		
		//populate ArrayLists of Course, Semester and Student with objects
		initSemesters(semesters, NUM_SEM);
		initCourses(courses, NUM_COURSES);
		initStudents(students, courses, pathToStudDemand); //read from a file
		
		final int NUM_STUD = students.size();
		Limits limit = new Limits(NUM_STUD, NUM_COURSES, NUM_SEM);
		
		// add set of Semesters to Courses that Student have to take
		addSemToCourses(courses, semesters);
		
	    /***************************************************************************
	    //			                     GUROBI 
	    *****************************************************************************/
        GRBEnv env;
		try {
			env = new GRBEnv("mip1.log");
			// prevent from outputting gurobi data to console
            //env.set(GRB.IntParam.LogToConsole, 0);
			GRBModel model = new GRBModel(env);
			
			//source used: https://www.gurobi.com/documentation/6.5/examples/sudoku_java.html
			GRBVar [][][] yijk = new GRBVar[NUM_STUD][NUM_COURSES][NUM_SEM];
			GRBVar X = model.addVar(0, 1000, 1.0, GRB.INTEGER, "X"); // largest class size
			
		    // populate 3D array of Binary guorobi varibales
			createGvars(yijk, limit, model);
			
			// Integrate new variables
		    model.update();
		    
		    String constrName; //constraint name
		    /****************************************************************************
		    // Constraint #1: Student can take no more than two classes in one semester
		    // Sum_j_(y_ijk) ≤ 2: y111 + y121 + y131 + y141 + ... y1Nj1 ≤ 2 (i, k = const)
		    *****************************************************************************/
		    GRBLinExpr maxCoursesConstraint;
			for(int i = 0; i < NUM_STUD; i++)
			{			
				for(int k = 0; k < NUM_SEM; k++)
				{
					maxCoursesConstraint = new GRBLinExpr();
					
					for(int j = 0; j < NUM_COURSES; j++)
					{
						// Set the constraint
						maxCoursesConstraint.addTerm(1, yijk[i][j][k]);
					}
					
					constrName = "MAXCOURSE_Student" + i + "_Semester" + k;
					model.addConstr(maxCoursesConstraint, GRB.LESS_EQUAL, 2, constrName);
				}
			}
			
			/*************************************************************************************
			// Constraint #2: Student Demand Data + constraint that course can be taken once
		    // 1D: (i, j = const) Sum_k_(y_ijk) = 1: y111 + y112 + y113 + y114 + ... y11k = 1 or 0
			**************************************************************************************/
		    GRBLinExpr mustTakeConstraint;
			for(int i = 0; i < NUM_STUD; i++)
			{
				for(int j = 0; j < NUM_COURSES; j++)
				{
					// check if Student ID[i+1] must take Course ID[j+1] during any of 12 semesters
					Set<Integer> courseSet = students.get(i).getCoursesIDSet();
					if(courseSet.contains(j+1))// course_ID starts from 1. Array from 0
					{
						mustTakeConstraint = new GRBLinExpr();
						
						for(int k = 0; k < NUM_SEM; k++)
						{
							// Set the constraint
							mustTakeConstraint.addTerm(1, yijk[i][j][k]);
						}
						
						constrName = "MUSTTAKE_Student_" + i + " Course_" + j;
						model.addConstr(mustTakeConstraint, GRB.EQUAL, 1, constrName);	
					}
					// if Student[i+1] must NOT take Course[j+1] during any of 12 semesters
					else
					{
						mustTakeConstraint = new GRBLinExpr();
						
						for(int k = 0; k < NUM_SEM; k++)
						{
							// Set the constraint
							mustTakeConstraint.addTerm(1, yijk[i][j][k]);
						}
						
						constrName = "MUSTNOTTAKE_Student_" + i + " Course_" + j;
						model.addConstr(mustTakeConstraint, GRB.EQUAL, 0, constrName);
					}//else
				}//for
			}//for
			
			/***********************************************************************************
			// Constraint #3: Courses Prerequisites. Class with a prerequisite can't be taken 
			// 1st semester. Source of the idea: https://piazza.com/class/ij4blvpmdri3ou?cid=99
			************************************************************************************/
		    GRBLinExpr PrereqFirstSemConstr;
			for(int i = 0; i < NUM_STUD; i++)
			{
				for(int j = 0; j < NUM_COURSES; j++)
				{
					// check if for Course ID[j+1] has a prerequisite Course
					Set<Integer> courseSet = courses.get(j).getPrereqIDSet();
					if(!courseSet.isEmpty())
					{
						PrereqFirstSemConstr = new GRBLinExpr();
						PrereqFirstSemConstr.addTerm(1, yijk[i][j][0]);

						constrName = "Course_" + (j+1) + " PREREQ_TO" + " 1stSem";
						model.addConstr(PrereqFirstSemConstr, GRB.EQUAL, 0, constrName);	
					}//if
				}//for j
			}//for i
			
			/********************************************************************************
			// Constraint #4: Courses Prerequisites
		    // 1D: You can use the first constraint in the paper, as long as you skip it for 
		     * any student that doesn't plan on taking the course that requires that pre-req.
			*********************************************************************************/
			/*GRBLinExpr PrereqConstrLess, PrereqConstrMore;
			for(int i = 0; i < NUM_STUD; i++)
			{
				for(int j = 0; j < NUM_COURSES; j++)
				{
					// check if for Course ID[j+1] there is a prerequisite Course
					Set<Integer> courseSet = courses.get(j).getPrereqIDSet();
					if(!courseSet.isEmpty())
					{
						// in case there are more than 1 prerequisite iterate through set
						for(int prereqID : courseSet) //prereqID is ID of prereq Course
						{
							PrereqConstrLess = new GRBLinExpr();
							PrereqConstrMore = new GRBLinExpr();
							
							for(int k = 0; k < NUM_SEM-1; k++)
							{
								// Set the constraint
								PrereqConstrLess.addTerm(1, yijk[i][j][k+1]);
								PrereqConstrMore.addTerm(1, yijk[i][prereqID-1][k]);
							}
							constrName = "Course_" + (prereqID) + " PREREQ_TO" + " Course_" + (j+1);
							model.addConstr(PrereqConstrLess, GRB.LESS_EQUAL, PrereqConstrMore, constrName);	
						}//for courseID
					}//if
				}//for j
			}//for*/
			
			/*******************************************************************
			Constraint #5: Capacity limits for one class at one semester
		    (j, k = const) Sum_i_(y_ijk) ≤ Ac,jk 
			1D: y111 + y211 + y311 + y411 + ... yNi11 ≤ capacity[j][k] 
			*******************************************************************/
		    GRBLinExpr maxCapacityConstraint;
		    for(int j = 0; j < NUM_COURSES; j++)
			{			
		    	for(int k = 0; k < NUM_SEM; k++)
				{
		    		// check if Course[j+1] is offered at Semester[k+1], then Sum of Students <= X
		    		Set<Integer> coursesIDSet = courses.get(j).getSemesterIDSet();
		    		if(coursesIDSet.contains(k+1))// k+1 because course_ID start at 1 vs. Array
		    		{
		    			maxCapacityConstraint = new GRBLinExpr();
						
						for(int i = 0; i < NUM_STUD; i++)
						{
							maxCapacityConstraint.addTerm(1, yijk[i][j][k]);
						}
						// for each course-semester pair, sum(students) <= X
						constrName = "CAPLIM_Course_" + j + " Semester_" + k;
						model.addConstr(maxCapacityConstraint, GRB.LESS_EQUAL, X, constrName);
		    		}//if
		    		
		    		// if Course[j+1] is NOT offered at Semester[k+1], then Sum of Students = 0
		    		else
		    		{
		    			maxCapacityConstraint = new GRBLinExpr();
						
						for(int i = 0; i < NUM_STUD; i++)
						{
							maxCapacityConstraint.addTerm(1, yijk[i][j][k]);
						}
						// for each course-semester pair, sum(students) = 0
						constrName = "CAPLIM_Course_" + j + " Semester_" + k;
						model.addConstr(maxCapacityConstraint, GRB.EQUAL, 0, constrName);
		    		}//else
				}//for k
			}//for j
		    
		    // Set objective: minimize X (minimize the largest class size)
		    GRBLinExpr objectiveExpr = new GRBLinExpr();
		    objectiveExpr.addTerm(1.0, X);
		    model.setObjective(objectiveExpr, GRB.MINIMIZE);
			
		    // Optimize the model
            model.optimize();

            // Display our results
            double objectiveValue = model.get(GRB.DoubleAttr.ObjVal);            
            System.out.printf( "Objective value = %f\n", objectiveValue);          
            
            System.out.println(X.get(GRB.StringAttr.VarName)
                    + " " +X.get(GRB.DoubleAttr.X));
            
            TestConstraints test = new TestConstraints();
            test.testDemand(yijk, limit);
            //test.testPrereq(yijk, limit, courses);
            
			// -------------------- TESTING OUTPUT ------------------------//
            // CAPACITY
			/*writer = new PrintWriter("cap.csv", "UTF-8");
            writer.println("course_ID,semester_ID,enrolled");
            sum=0;
            for(int j = 0; j < NUM_COURSES; j++)
			{			
            	for(int k = 0; k < NUM_SEM; k++)
				{
            		sum = 0;
            		for(int i = 0; i < NUM_STUD; i++)
					{
		    			
		    			if(yijk[i][j][k].get(GRB.DoubleAttr.X) > 0)
		    			{
		    				sum = sum + yijk[i][j][k].get(GRB.DoubleAttr.X);
		    				//System.out.println(yijk[i][j][k].get(GRB.StringAttr.VarName)
				            //        + ", " + yijk[i][j][k].get(GRB.DoubleAttr.X));
		    			}	
					}
            		//if(sum >0)
            		{
            			String line = (j+1)+ ","+ (k+1) + "," + sum;
            			System.out.println(line);
            			writer.println(line);
            		}
				}
			}writer.close();*/

            // Dispose of model and environment
            model.dispose();
            env.dispose();

			//float result = (float) 3.1415;
			//System.out.printf("X=%.2f", result);

		} catch (GRBException | FileNotFoundException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}//end try-catch
		
		
	}//calculateSchedule()
	
	
	/******************************************************************************
	Function: createGvars
	
	Purpose:  Create 3D array of references to gurobi variables
	
	Receives: 
		- GRBVar [][][] yijk: 3D empty array for GRBVar instances
		- Limits liimit: class that provides num of studs, courses, semesters
	
	Returns:  None
	
	Pre:      limits != null, model != null
	
	Post:     create references to Binary gurobi variables in 3D array 
	******************************************************************************/
	public void createGvars(GRBVar [][][] yijk, Limits limit, GRBModel model) throws GRBException
	{
		// Gurobi var name to reference later
		String gvar_name = "";
		for(int i = 0; i < limit.stud; i++)
		{
			for(int j = 0; j < limit.cour; j++)
			{
				for(int k = 0; k < limit.sem; k++)
				{
					gvar_name = "BIN_" + String.valueOf(i+1) + 
								"_" + String.valueOf(j+1) + 
								"_" + String.valueOf(k+1);
					
					// lower bound, upper bound, Objective coefficient=0 (is set later), type, name
					yijk[i][j][k] = model.addVar(0, 1, 0.0, GRB.BINARY, gvar_name);
				}
			}
		}
	}//createGvars
	
	

	/******************************************************************************
	Function: initSemesters -- hard coded
	
	Purpose:  Initialize ArrayList of Semesters
	
	Receives: 
		- ArrayList<Semester> sems 
		- int NUM_SEM - number of semsters
	
	Returns:  None
	
	Pre:      sems isEmpty
	
	Post:     Initialized ArrayList of Semesters
	******************************************************************************/
	private void initSemesters(ArrayList<Semester> sems, int NUM_SEM)
	{
		//semester_id starts from 1
		for(int i = 1; i <= NUM_SEM; i++)
			sems.add(new Semester(i));
	}
	
	/******************************************************************************
	Function: initCourses -- hard coded
	
	Purpose:  Initialize ArrayList of Courses
	
	Receives: 
		- ArrayList<Course> courses 
		- int NUM_COURSES - number of courses
	
	Returns:  None
	
	Pre:      courses isEmpty
	
	Post:     Initialized ArrayList of Courses
	******************************************************************************/
	private void initCourses(ArrayList<Course> courses, int NUM_COURSES)
	{
		
		//course_id starts from 1
		for(int i = 1; i <= NUM_COURSES; i++)
		{
			//Course course = new Course(i);
			courses.add(new Course(i));
		}
		
		// Add prerequisite Courses
		for(int i = 1; i <= NUM_COURSES; i++)
		{
			if(i == 16)
				courses.get(i-1).addPrereq(courses.get(3));
			else if(i == 1)
				courses.get(i-1).addPrereq(courses.get(11));
			else if(i == 13)
				courses.get(i-1).addPrereq(courses.get(8));
			else if(i == 7)
				courses.get(i-1).addPrereq(courses.get(2));
		}	
	}
	
	
	/******************************************************************************
	Function: addSemToCourses
	
	Purpose:  Adds Set of Semesters to each Course object
	
	Receives: 
		- ArrayList<Course> courses 
		- ArrayList<Semester> semesters
	
	Returns:  None
	
	Pre:      None
	
	Post:     Courses have set of semesters when they offered
	******************************************************************************/
	private void addSemToCourses(ArrayList<Course> courses, ArrayList<Semester> semesters)
	{
		int courseID;
		// create set of Fall courses
		Set<Integer> setFall = new HashSet<Integer>();
		setFall.add(1); setFall.add(7); setFall.add(11); setFall.add(15);
		setFall.add(17);
		
		// create set of Spring courses
		Set<Integer> setSpring = new HashSet<Integer>();
		setSpring.add(5); setSpring.add(10); setSpring.add(14); setSpring.add(16);
		setSpring.add(18);
		
		for(Course course : courses)
		{
			courseID = course.getCourse_ID();
			
			// if courseID is in Fall set,
			if(setFall.contains(courseID))
			{
				//add all Fall semesters to the given course
				for(Semester semester : semesters)
				{
					if(semester.getSeason() == "Fall")
						course.addSemester(semester);
				}
					
			}
			
			// if courseID is in Spring set
			else if(setSpring.contains(courseID))
			{
				//add all Spring semesters to the given course
				for(Semester semester : semesters)
				{
					if(semester.getSeason() == "Spring")
						course.addSemester(semester);
				}
			}
			
			// course is offered every semester
			else
			{
				// add all semesters to the given course
				for(Semester semester : semesters)
					course.addSemester(semester);
			}
				
		}//for
	}//addSemToCourses
	
	/******************************************************************************
	Function: initStudents
	
	Purpose:  Gets list of students from student_demand file and populates
			  ArrayList with Student objects
	
	Receives: 
		- ArrayList<Student> students 
		- ArrayList<Course> courses
		- String pathToStudDemand
	Returns:  None
	
	Pre:      courses isEmpty
	
	Post:     ArrayList is populated with Student objects from a data file
	******************************************************************************/
	private void initStudents(ArrayList<Student> students, ArrayList<Course> courses, String pathToStudDemand)
	{
		// to save data from csv file
		Map<Integer, Set<Integer>> studentData = new HashMap<Integer, Set<Integer>>();
		
		// read csv file to map of integer sets
		CsvReader csv = new CsvReader();
		studentData = csv.readFile(pathToStudDemand);
		
		// source: https://dzone.com/articles/the-magic-word-in-java-cafebabe
		// iterate over the map of student demand read from a file 
		for (Map.Entry<Integer, Set<Integer>> entry : studentData.entrySet()) 
		{
			// get key and mapped set of course integers
			int studID = entry.getKey();
			Set<Integer> courseSet = entry.getValue();
			
			// create new Student object
			Student student = new Student(studID);
			
			// add courses to Student obj
			for(Course course : courses)
			{
				if(courseSet.contains(course.getCourse_ID()))
					student.addCourse(student, course);
			}
			// add to ArrayList<Student>
			students.add(student);
		}//for
	}//initStudents
	
	public double getObjectiveValue() {
		// TODO: You will need to implement this
		return 0;
	}

	public Vector<String> getCoursesForStudentSemester(String student, String semester) {
		// TODO: You will need to implement this
		return null;
	}

	public Vector<String> getStudentsForCourseSemester(String course, String semester) {
		// TODO: You will need to implement this
		return null;
	}

}
