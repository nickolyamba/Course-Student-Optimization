package edu.gatech.cs6310.projectOne;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Set;

import gurobi.GRB;
import gurobi.GRBException;
import gurobi.GRBVar;

public class TestConstraints {

	public TestConstraints() {
		// TODO Auto-generated constructor stub
	}
	
	public void testDemand(GRBVar [][][] yijk, Project1Scheduler.Limits limit) 
			throws FileNotFoundException, UnsupportedEncodingException, GRBException{
		// -------------------- TESTING DEMAND ------------------------//
	    // DEMAND
	    PrintWriter writer = new PrintWriter("10pre.csv", "UTF-8");
	    writer.println("student_ID,course_ID");
	    double sum=0;
	    for(int i = 0; i < limit.stud; i++)
		{			
	    	for(int j = 0; j < limit.cour; j++)
			{
	    		sum = 0;
	    		for(int k = 0; k < limit.sem; k++)
				{
	    			
	    			if(yijk[i][j][k].get(GRB.DoubleAttr.X) > 0)
	    			{
	    				sum = sum + yijk[i][j][k].get(GRB.DoubleAttr.X);
	    				//System.out.println(yijk[i][j][k].get(GRB.StringAttr.VarName)
			            //        + ", " + yijk[i][j][k].get(GRB.DoubleAttr.X));
	    			}	
				}
	    		if(sum >0)
	    		{
	    			String line = i+1 + "," + (j+1);
	    			//System.out.println(line);
	    			//writer.println(line);
	    		}
			}
		}writer.close();
	}//testDemand
	
	public void testPrereq(GRBVar [][][] yijk, Project1Scheduler.Limits limit, ArrayList<Course> courses) 
			throws FileNotFoundException, UnsupportedEncodingException, GRBException{
		// -------------------- TESTING PREREQUSITE ------------------------//
	    //PrintWriter writer = new PrintWriter("10pre.csv", "UTF-8");
	    //writer.println("student_ID,course_ID");
	    String line="None";
	    System.out.println("Stud\t" + "Course\t\t" + "Prereq\t" + "Result");
	    for(int i = 0; i < limit.stud; i++)
		{			
	    	for(int j = 0; j < limit.cour; j++)
			{
	    		Set<Integer> courseSet = courses.get(j).getPrereqIDSet();
				if(!courseSet.isEmpty())
				{
					for(int prereqID : courseSet)
					{
						for(int k = 0; k < limit.sem; k++)
						{
		    				if(yijk[i][j][k].get(GRB.DoubleAttr.X) > 0)
		    				{
		    					line = (i+1) + "\t" +(j+1) + " (" + (k+1) + ")"+"\t\t";
		    					
		    					
		    					for(int z = 0; z < limit.sem; z++)
		    					{
		    						if(yijk[i][prereqID-1][z].get(GRB.DoubleAttr.X) > 0)
		    						{
		    							String result = (z < k) ? "+" : "-";
		    							System.out.println(line + prereqID + " (" + (z+1) + ")" + "\t\t" + result);

		    						}
		    							
		    					}//for z
		    				}//if
		    				
						}//for k
					}
				}
			}
		}
	    /*
	    System.out.print(yijk[0][15][10].get(GRB.DoubleAttr.X) + "  ");
	    System.out.println(yijk[0][3][8].get(GRB.DoubleAttr.X) + "  ");
	    
	    System.out.print(yijk[4][0][9].get(GRB.DoubleAttr.X) + "  ");
	    System.out.println(yijk[4][11][2].get(GRB.DoubleAttr.X) + "  ");
	    
	    System.out.print(yijk[5][15][4].get(GRB.DoubleAttr.X) + "  ");
	    System.out.println(yijk[5][3][10].get(GRB.DoubleAttr.X) + "  ");
	    */
	}//testPrereq
}
	    

