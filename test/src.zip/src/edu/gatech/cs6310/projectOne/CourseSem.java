package edu.gatech.cs6310.projectOne;

public class CourseSem {
	private Semester semester;
	
	public CourseSem(Semester semester) {
		this.semester = semester;
	}

	/**
	 * @return the semester
	 */
	public Semester getSemester() {
		return semester;
	}

	/**
	 * @param semester the semester to set
	 */
	public void setSemester(Semester semester) {
		this.semester = semester;
	}

}
